Este arquivo explica detalhes do repositório, quais são suas pastas etc.
